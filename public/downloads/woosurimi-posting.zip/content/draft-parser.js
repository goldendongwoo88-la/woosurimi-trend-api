// 클로드가 써준 원고를 편집기에 넣을 수 있는 형태로 뜯어냅니다.
//
// ⚠️ 왜 필요한가
// 사장님은 Claude Pro Max 구독을 쓰십니다. claude.ai나 Claude Code에서 원고를 쓰면
// **API 값이 0원**입니다. 우수리미 사이트에서 뽑으면 한 편에 740원씩 나갑니다.
// 그런데 클로드에서 쓰면 편집기로 옮기는 게 손일입니다 — 복사, 붙여넣기,
// 소제목 하나하나 드롭다운, 사진 자리 찾기, 강조...
// 그 손일을 없애면 **공짜로 쓰면서 손도 안 갑니다.**
//
// ⚠️ 이 파일은 AI를 안 부릅니다. 전부 규칙으로 뜯어냅니다. 값이 안 나갑니다.
//
// ⚠️ 클로드 원고의 생김새 (제가 쓰는 형식입니다)
//   # 제목                      ← 맨 위 한 줄
//   ■ 소제목                    ← ■ [소제목] ## ▶ ◆ ●
//   [사진 1: 무엇]              ← 사진 자리
//   > 인용구                    ← 인용으로 쓸 문장
//   **굵게**                    ← 강조
//   본문 문단들
//
// 단계별 출력(제목 45개 등)이 섞여 있으면 **본문 부분만** 골라냅니다.

(() => {
  "use strict";

  const INVIS = /[\s​-‍⁠﻿]/g;
  const vis = (s) => String(s || "").replace(INVIS, "").length;

  /** 소제목 표시 — src/emphasis.js와 같은 목록입니다. */
  const SUBHEAD = [
    /^\s*■\s*/,
    /^\s*\[소제목\]\s*/,
    /^\s*#{2,3}\s+/,
    /^\s*▶\s*/,
    /^\s*◆\s*/,
    /^\s*●\s*/,
  ];

  const PHOTO = /^\s*\[사진\s*\d*\s*[:：]?\s*([^\]]*)\]\s*$/;
  const QUOTE = /^\s*>\s+(.+)$/;
  const H1 = /^\s*#\s+(.+)$/;

  /**
   * 단계별 출력에서 **본문만** 골라냅니다.
   *
   * ⚠️ 클로드 스킬은 7단계를 밟습니다. 제목 45개, 소제목 목록, 본문, 팩트체크,
   * 이미지 프롬프트... 그중 편집기에 넣을 건 **본문 하나**입니다.
   * 다 넣으면 제목 45개가 글에 들어갑니다.
   */
  function pickBody(raw) {
    let text = String(raw || "");

    /**
     * ⚠️ 클로드가 본문을 ``` 로 감싸서 주는 일이 많습니다. 그리고 그 **뒤에**
     * 자기가 무슨 일을 했는지 적어둡니다. 실제로 이렇게 왔습니다:
     *
     *   ```
     *   ■ 공항에서 포착된 한 벌
     *   ... (진짜 본문)
     *   ```
     *   **글자 수: 공백 제외 847자**
     *   **참고:**
     *   - 소제목 6개 구성
     *   - 협찬 아님 → 글 끝 링크카드는 사장님이 직접 추가하시면 됩니다
     *
     * 이걸 그냥 두면 **"소제목 6개 구성"이 블로그에 올라갑니다.**
     * 사장님한테 하는 말이 손님한테 보이는 겁니다.
     * 게다가 ``` 는 ` 한 개로 줄어들어 본문에 덩그러니 남았습니다.
     *
     * 감싼 게 있으면 **그 안쪽만** 씁니다. 그러면 두 문제가 한 번에 풀립니다.
     */
    const fenced = text.match(/```[a-zA-Z]*\s*\n([\s\S]*?)\n\s*```/);
    if (fenced && fenced[1].trim().length > 200) text = fenced[1];

    /**
     * ⚠️ 감싸지 않고 뒤에 설명만 붙이는 경우도 있습니다.
     * "**참고:**", "**글자 수: …**" 같은 줄부터는 본문이 아닙니다.
     * 이건 **글 끝쪽에서만** 자릅니다 — 가운데서 자르면 진짜 글을 잃습니다.
     */
    const all = text.split("\n");
    const META = /^\s*(?:\*\*)?\s*(참고|메모|비고|설명|글자\s*수|자수|총\s*글자)\s*[:：]?\s*(?:\*\*)?\s*$|^\s*\*\*\s*글자\s*수\s*[:：]/;
    for (let i = Math.floor(all.length * 0.6); i < all.length; i++) {
      if (META.test(all[i])) { text = all.slice(0, i).join("\n"); break; }
    }

    // ⚠️ 위의 감싼 것 꺼내기는 **알맹이가 200자 넘을 때만** 합니다.
    // 짧은 코드 조각을 본문으로 착각하면 글을 통째로 잃으니까요.
    // 그래서 짧게 감싸 온 경우엔 ``` 가 그대로 남습니다.
    //
    // ``` 만 있는 줄은 **어떤 경우에도 블로그 글이 아닙니다.** 그냥 버립니다.
    // (안 버리면 clean()이 ``` 를 ` 하나로 줄여서 본문에 덩그러니 남깁니다)
    const lines = text.split("\n").filter((l) => !/^\s*`{3,}[a-zA-Z]*\s*$/.test(l));

    // "4단계", "본문", "본문 출력" 같은 표시가 있으면 그 뒤부터 봅니다.
    //
    // ⚠️ \b(낱말 경계)를 쓰면 안 됩니다. 자바스크립트의 \b는 영문자·숫자 기준이라
    // **한글 뒤에서는 안 먹습니다.** "4단계:"에서 '계'와 ':' 사이에는 경계가 없어서
    // /4단계\b/ 가 아예 안 맞습니다. 실제로 이것 때문에 본문을 못 잘라냈고,
    // 1단계 제목 45개가 통째로 원고에 들어갔습니다.
    //
    // ⚠️ 그런데 이번엔 **반대 방향으로** 틀렸습니다. 이렇게 돼 있었습니다:
    //     /^\s*#{0,4}\s*(4단계|본문 작성|본문 출력|본문)\s*[:：\-—]?/
    // 줄 끝을 안 묶어놔서 **"본문"으로 시작하는 아무 문장이나** 걸렸습니다.
    //
    //     "본문입니다."                → 표시로 잘못 보고 그 앞을 전부 버렸습니다
    //     "썸네일은 밝은 걸로 골랐어요"  → 여기서 본문을 끊어버렸습니다
    //
    // 사장님 글이 **말없이 사라집니다.** 표시를 못 찾는 것보다 훨씬 나쁩니다.
    // 못 찾으면 통째로 들어가서 바로 보이지만, 이건 조용히 없어집니다.
    //
    // 그래서 **줄 전체가 표시일 때만** 인정합니다.
    const START = /^(\d+\s*단계)?\s*[:：\-—]?\s*(본문(\s*(작성|출력))?)?$/;
    const STOP = /^(\d+\s*단계)?\s*[:：\-—]?\s*(팩트\s*체크|이미지\s*프롬프트|썸네일|인포그래픽|해시태그)?$/;

    /** 머리글 표시(#)를 떼고 남은 알맹이. 길면 표시가 아니라 문장입니다. */
    const marker = (line) => {
      const t = String(line).replace(/^\s*#{0,4}\s*/, "").trim();
      return t && t.length <= 20 ? t : null;
    };
    const isStart = (line) => {
      const t = marker(line);
      // 알맹이가 있어야 하고(빈 줄 제외), 단계나 본문이라는 말이 실제로 있어야 합니다.
      return !!t && START.test(t) && /단계|본문/.test(t);
    };
    const isStop = (line) => {
      const t = marker(line);
      if (!t || !STOP.test(t)) return false;
      // "4단계"는 시작이지 끝이 아닙니다. 5단계부터가 끝입니다.
      const step = t.match(/^(\d+)\s*단계/);
      if (step) return Number(step[1]) >= 5;
      return /팩트|이미지|썸네일|인포그래픽|해시태그/.test(t);
    };

    let from = -1, to = lines.length;
    for (let i = 0; i < lines.length; i++) {
      if (from < 0 && isStart(lines[i])) { from = i + 1; continue; }
      if (from >= 0 && isStop(lines[i])) { to = i; break; }
    }
    if (from >= 0) return lines.slice(from, to).join("\n");

    // 단계 표시가 없으면 통째로 씁니다. 다만 제목 목록처럼 보이면 걷어냅니다.
    //
    // ⚠️ 여기서 text 를 그대로 돌려주면 안 됩니다. 위에서 걸러낸 ``` 줄이
    // 되살아납니다. 실제로 그랬습니다 — 필터를 넣었는데도 백틱이 남았습니다.
    // 걸러낸 결과(lines)를 돌려줘야 합니다.
    return lines.join("\n");
  }

  /**
   * 제목 목록으로 보이는 덩어리를 걷어냅니다.
   *
   * ⚠️ 제목 45개가 "1. …" "2. …" 로 죽 나열됩니다. 그게 본문에 들어가면 안 됩니다.
   * 번호가 붙은 짧은 줄이 5개 넘게 이어지면 목록으로 봅니다.
   */
  function dropTitleList(lines) {
    const out = [];
    let run = [];
    const isNumbered = (l) => /^\s*\d+[.)]\s+\S/.test(l) && vis(l) < 60;
    for (const l of lines) {
      if (isNumbered(l)) { run.push(l); continue; }
      if (run.length >= 5) run = [];          // 목록이었다 — 버립니다
      else out.push(...run), (run = []);      // 몇 개뿐이면 본문입니다
      out.push(l);
    }
    if (run.length < 5) out.push(...run);
    return out;
  }

  /**
   * 원고를 덩어리로 뜯습니다.
   * @returns {{title, blocks: Array<{kind, text, marks?}>}}
   */
  function parse(raw) {
    // ⚠️ [강조]…[/강조] 는 편집국(8485) 원고의 굵게 표시입니다. 파서가 몰라서
    // 태그가 글자 그대로 발행될 뻔했습니다 (2026-08-28 실사용에서 발견).
    // **…** 로 바꿔서 기존 굵게 처리에 태웁니다.
    raw = String(raw || "").replace(/\[강조\]([\s\S]*?)\[\/강조\]/g, "**$1**");
    const body = pickBody(raw);
    let lines = body.split("\n");
    lines = dropTitleList(lines);

    let title = "";
    const blocks = [];

    for (const rawLine of lines) {
      const line = rawLine.replace(/\r/g, "");
      const t = line.trim();

      if (!t) {
        // 빈 줄은 문단 구분입니다. 이어진 빈 줄은 하나로 봅니다.
        if (blocks.length && blocks[blocks.length - 1].kind !== "gap") blocks.push({ kind: "gap" });
        continue;
      }

      // 제목 — 맨 처음 나오는 # 한 줄
      const h1 = t.match(H1);
      if (h1 && !title) { title = clean(h1[1]); continue; }

      // 사진 자리
      const ph = t.match(PHOTO);
      if (ph) { blocks.push({ kind: "photo", text: clean(ph[1] || "") }); continue; }

      // 인용구
      const q = t.match(QUOTE);
      if (q) { blocks.push({ kind: "quote", text: clean(q[1]) }); continue; }

      // 소제목
      let sub = null;
      for (const re of SUBHEAD) {
        if (re.test(t)) {
          const c = clean(t.replace(re, ""));
          if (c.length >= 3 && c.length <= 45) { sub = c; break; }
        }
      }
      if (sub) { blocks.push({ kind: "subhead", text: sub }); continue; }

      // 그 밖에는 본문. **굵게** 표시를 뽑아둡니다.
      const marks = [];
      for (const m of t.matchAll(/\*\*(.+?)\*\*/g)) marks.push(m[1]);
      blocks.push({ kind: "text", text: clean(t), marks });
    }

    // 앞뒤 빈 줄 정리
    while (blocks.length && blocks[0].kind === "gap") blocks.shift();
    while (blocks.length && blocks[blocks.length - 1].kind === "gap") blocks.pop();

    /**
     * 제목 표시가 없을 때 — 첫 줄이 **제목처럼 생겼을 때만** 제목으로 씁니다.
     *
     * ⚠️ 예전에는 "글 문단 중 8~60자짜리 아무거나" 집어서 제목으로 썼습니다.
     * 그러다 이런 일이 났습니다 (흉내 편집기 시험에서 잡았습니다):
     *
     *   원고: "택배 상자를 열자마자 색이 눈에 들어왔습니다." 로 시작
     *   결과: 그 문장이 **제목 칸에 들어가고 본문에서는 사라졌습니다.**
     *         사장님이 이미 써두신 제목도 덮어썼습니다.
     *
     * 두 가지가 겹쳐 나쁩니다 — 글 한 줄이 없어지고, 제목이 바뀝니다.
     * 둘 다 사장님이 눈치채기 어렵습니다.
     *
     * 그래서 조건을 좁힙니다:
     *   1) **맨 첫 덩이**여야 합니다. 중간 문장은 절대 제목이 아닙니다.
     *   2) 마침표·물음표로 끝나면 안 됩니다. 그건 문장이지 제목이 아닙니다.
     *   3) 8~45자.
     *
     * 애매하면 **그냥 둡니다.** 제목을 못 넣는 건 사장님이 바로 아시지만,
     * 멋대로 바꾼 건 모르고 지나갑니다. 모르고 지나가는 쪽이 더 나쁩니다.
     */
    if (!title && blocks[0] && blocks[0].kind === "text") {
      const t = blocks[0].text;
      const looksLikeSentence = /[.!?…。]$/.test(t);
      if (!looksLikeSentence && vis(t) >= 8 && vis(t) <= 45) {
        title = t;
        blocks.shift();
      }
    }

    return { title, blocks, stats: summarize(blocks) };
  }

  /** 마크다운 표시를 뗍니다. 편집기에는 서식으로 넣지 글자로 넣지 않습니다. */
  function clean(s) {
    return String(s || "")
      .replace(/\*\*(.+?)\*\*/g, "$1")
      .replace(/__(.+?)__/g, "$1")
      .replace(/`(.+?)`/g, "$1")
      .replace(/^\s*[-*]\s+/, "")
      .trim();
  }

  function summarize(blocks) {
    const t = blocks.filter((b) => b.kind === "text");
    const lens = t.map((b) => vis(b.text)).sort((a, b) => a - b);
    return {
      subheads: blocks.filter((b) => b.kind === "subhead").length,
      quotes: blocks.filter((b) => b.kind === "quote").length,
      photos: blocks.filter((b) => b.kind === "photo").length,
      paras: t.length,
      chars: t.reduce((n, b) => n + vis(b.text), 0),
      paraMedian: lens.length ? lens[Math.floor(lens.length / 2)] : 0,
      over45: t.length ? Math.round((t.filter((b) => vis(b.text) > 45).length / t.length) * 100) : 0,
      marks: t.reduce((n, b) => n + (b.marks ? b.marks.length : 0), 0),
    };
  }

  const api = { parse, pickBody, dropTitleList, clean };

  // ⚠️ 확장 프로그램(브라우저)과 자동화 도구(서버)가 **같은 코드**를 씁니다.
  // 두 군데에 따로 적어두면 언젠가 어긋나고, 그러면 화면에서 되던 게
  // 자동화에서는 안 되는 일이 생깁니다. 그때 원인 찾기가 아주 어렵습니다.
  if (typeof window !== "undefined") window.__wsDraft = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
